import { useState } from "react";

export default function Home() {
  const [trucks, setTrucks] = useState([]);
  const [form, setForm] = useState({
    from: "",
    to: "",
    type: "Standard",
    date: "",
    comment: "",
    name: ""
  });

  const handleAdd = () => {
    if (!form.from || !form.to) return;
    setTrucks([
      ...trucks,
      { ...form, id: Date.now(), status: "available" }
    ]);
    setForm({ from: "", to: "", type: "Standard", date: "", comment: "", name: "" });
  };

  const takeTruck = (id, name) => {
    setTrucks(trucks.map(t =>
      t.id === id ? { ...t, status: "taken", name } : t
    ));
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Add Truck</h2>
      <input placeholder="From" value={form.from} onChange={e => setForm({...form, from: e.target.value})} /><br/>
      <input placeholder="To" value={form.to} onChange={e => setForm({...form, to: e.target.value})} /><br/>

      <select value={form.type} onChange={e => setForm({...form, type: e.target.value})}>
        <option>Sprinter</option>
        <option>BOX</option>
        <option>Frigo</option>
        <option>ADR</option>
        <option>Standard</option>
        <option>Mega</option>
      </select><br/>

      <input type="date" value={form.date} onChange={e => setForm({...form, date: e.target.value})} /><br/>
      <input placeholder="Comment" value={form.comment} onChange={e => setForm({...form, comment: e.target.value})} /><br/>

      <button onClick={handleAdd}>Add Truck</button>

      <h2>Trucks</h2>
      {trucks.map(t => (
        <div key={t.id} style={{ border: "1px solid #ccc", margin: 10, padding: 10 }}>
          <p>{t.from} → {t.to} | {t.type}</p>
          <p>Status: {t.status === "taken" ? `taken by ${t.name}` : "available"}</p>
          <p>Comment: {t.comment}</p>
          {t.status === "available" && (
            <>
              <input placeholder="Your name" onChange={e => setForm({...form, name: e.target.value})}/>
              <button onClick={() => takeTruck(t.id, form.name)}>Take</button>
            </>
          )}
        </div>
      ))}
    </div>
  );
}
